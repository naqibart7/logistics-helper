
import { generateId } from './helpers';

const cleanCurrency = (str) => {
    if (!str) return 0;
    return parseFloat(str.replace(/[^\d.-]/g, '')) || 0;
};

// ──────────────────────────────────────────────
// STRICT PARSER IMPLEMENTATION (FULL AUDITED V2)
// ──────────────────────────────────────────────
const parseJobCost = (text) => {
    const lines = text
        .split('\n')
        .map(l => l.trim())
        .filter(l => l.length > 12);

    const materials = [];
    let currentCategory = null;
    let insideValidMaterialSection = false;
    let insideValidSupportingSection = false;

    for (const line of lines) {
        const lower = line.toLowerCase();

        let headerDetected = false;

        // ──────────────────────────────────────────────
        // 1. DETECT MATERIALS CONTEXT
        // ──────────────────────────────────────────────
        // Checks for keyword triggers that indicate a Material Item OR Section
        if (
            lower.includes('gypsum') ||
            lower.includes('cement board') ||
            lower.includes('plywood') ||
            lower.includes('plaster') ||
            lower.includes('pvc') ||
            lower.includes('hpl') ||
            lower.includes('laminate') ||
            lower.includes('acrylic') ||
            lower.includes('wpc') ||
            lower.includes('fluted') ||
            lower.includes('skirting') ||
            lower.includes('glass') ||
            lower.includes('sticker') ||
            lower.includes('mirror') ||
            lower.includes('blockboard') ||
            lower.includes('furniture') ||
            lower.includes('lighting') ||
            lower.includes('lamp') ||
            lower.includes('led') ||
            lower.includes('downlight') ||
            lower.includes('eyeball') ||
            lower.includes('fan') ||
            lower.includes('tiles') ||
            lower.includes('flooring') ||
            lower.includes('carpet') ||
            lower.includes('underlay') ||
            lower.includes('canvas') ||
            lower.includes('scaffolding') ||
            lower.includes('roro') ||
            lower.includes('bin')
        ) {
            currentCategory = 'MATERIALS';
            insideValidMaterialSection = true;
            insideValidSupportingSection = false;
            headerDetected = true;
        }

        // ──────────────────────────────────────────────
        // 2. DETECT SUPPORTING CONTEXT (Prioritized)
        // ──────────────────────────────────────────────
        if (
            lower.includes('supporting material') ||
            lower.includes('metal stud') ||
            lower.includes('corner bead') ||
            lower.includes('joint tape') ||
            lower.includes('flaxi') ||
            lower.includes('drywall screw') ||
            lower.includes('x-bond') ||
            lower.includes('super glue') ||
            lower.includes('silicon') ||
            lower.includes('masking') ||
            lower.includes('wire') ||
            lower.includes('cable') ||
            lower.includes('suis') ||
            lower.includes('socket') ||
            lower.includes('switch') ||
            lower.includes('bulb') ||
            lower.includes('hinge') ||
            lower.includes('door closer') ||
            lower.includes('door stopper') ||
            lower.includes('door knob') ||
            lower.includes('lock') ||
            lower.includes('screw') ||
            lower.includes('nail') ||
            lower.includes('l-profile') ||
            lower.includes('besi') ||
            lower.includes('kayu kocai') ||
            lower.includes('thinner') ||
            lower.includes('roller') ||
            lower.includes('brush') ||
            lower.includes('undercoat') ||
            lower.includes('primer')
        ) {
            currentCategory = 'SUPPORTING MATERIAL';
            insideValidSupportingSection = true;
            insideValidMaterialSection = false;
            headerDetected = true;
        }

        // ──────────────────────────────────────────────
        // 3. HARD STOPS – Exit Current Section
        // ──────────────────────────────────────────────
        if (
            lower.includes('labour work') ||
            lower.includes('transport') ||
            // Site Prep is ALLOWED now (has trigger above)
            lower.includes('free gift') ||
            lower.includes('pakej') ||
            lower.includes('summary of tpc') ||
            lower.includes('method c') ||
            lower.includes('total (cogs)') ||
            lower.includes('total installation') ||
            lower.includes('total transport') ||
            lower.includes('total sub paint') ||
            lower.includes('commission') ||
            lower.includes('contigency') ||
            lower.includes('opex') ||
            // Paint Summaries (Block explicit)
            lower.includes('cat dekat site') ||
            lower.includes('jotun') ||
            lower.includes('suzuka') ||
            line.includes('--- PAGE BREAK ---')
        ) {
            insideValidMaterialSection = false;
            insideValidSupportingSection = false;
            continue;
        }

        // ──────────────────────────────────────────────
        // 4. JUNK FILTER – Skip Line (Keep Context)
        // ──────────────────────────────────────────────
        if (
            line.includes('SQFT /') ||
            line.includes('QTY (PCS)') ||
            line.includes('QTY LEBIHKAN') ||
            line.includes('KALAU') ||
            line.includes('TERMASUK') ||
            line.match(/^\d+\s*$/) ||
            line.endsWith('RM 0.00') ||
            line.includes('RM       0.00') ||
            line.includes('RM 0.00') ||
            // Spec placeholders moved here to avoid breaking context
            lower.includes('spec') ||
            lower.includes('insert') ||
            lower.includes('masukkan') ||
            line.includes('→')
        ) continue;

        // ──────────────────────────────────────────────
        // 5. PARSE ITEM
        // ──────────────────────────────────────────────
        let cleaned = line.replace(/\s{2,}/g, '  ').trim();

        // Must find Price at End
        const totalMatch = cleaned.match(/(RM\s*[\d,]+\.?\d*)$/i);

        if (!totalMatch) {
            continue; // Skip headers/text without price
        }

        // Ensure we are in valid context OR self-healed by trigger
        if (!insideValidMaterialSection && !insideValidSupportingSection) continue;

        const totalPart = totalMatch[0];
        if (totalPart.includes('0.00')) continue;

        const total = parseFloat(totalPart.replace(/RM\s*/i, '').replace(/,/g, ''));
        if (total <= 0) continue;

        cleaned = cleaned.replace(totalMatch[0], '').trim();

        // Default Split
        let parts = cleaned.split(/\s{2,}/).filter(Boolean);
        let usedFallback = false;

        // Fallback Split (Single Spaces)
        if (parts.length < 2) {
            parts = cleaned.split(/\s+/).filter(Boolean);
            usedFallback = true;
        }

        if (parts.length < 2) continue;

        let price = null;
        let qty = null;

        // Price
        let candidate = parts.pop();
        if (candidate.match(/^\d+\.?\d{0,2}$/)) {
            price = parseFloat(candidate);
        } else {
            parts.push(candidate);
        }

        // Qty
        if (parts.length > 0) {
            candidate = parts.pop();
            if (candidate.match(/^\d+\.?\d*$/)) {
                qty = parseFloat(candidate);
            } else {
                parts.push(candidate);
            }
        }

        // Clean Tail Junk (Dimensions) if using fallback
        if (usedFallback) {
            while (parts.length > 0) {
                const last = parts[parts.length - 1];
                if (last.match(/^\d+(\.\d+)?$/)) { // Pure number
                    parts.pop();
                } else {
                    break;
                }
            }
        }

        let item = parts.join(' ').trim();

        // Clean Leading Index (1-3 digits) purely for standard list indices
        item = item.replace(/^\d{1,3}\s+/, '');

        // Clean Header Artifacts
        item = item.replace(/^(NEW STRUCTURE|CEILING|WALL PANEL|WALL FINISHES|GLASS FINISHES|FURNITURE|LIGHTING|TILES|FLOORING|PAINT|SITE PREPARATION)\s*/i, '');

        // Final Sanity
        if (
            item.length < 2 ||
            !qty ||
            item.includes('TOTAL') ||
            item.includes('SUB') ||
            item.includes('INSTALLATION') ||
            item.includes('TRANSPORT') ||
            item.includes('SUMMARY')
        ) continue;

        materials.push({
            id: generateId(),
            category: currentCategory,
            item,
            quantity: qty,
            unit: 'pcs',
            unitPrice: price || (qty ? total / qty : 0),
            price: total,
            total
        });
    }

    return materials;
};

export const smartParse = (text) => {
    const lines = text.split('\n');
    let detectedFormat = 'JOB_COST';
    const lowerText = text.toLowerCase();

    if (lowerText.includes('quotation') && (lowerText.includes('qty') || lowerText.includes('quantity')) && !lowerText.includes('job cost')) {
        detectedFormat = 'MATERIAL_COST';
    }

    let metadata = {
        projectName: '',
        clientName: '',
        quotationNumber: '',
        date: '',
        totalProject: ''
    };

    lines.forEach(line => {
        if (line.match(/PROJECT\s*[:]/i) || line.includes('PROJECT NAME')) {
            metadata.projectName = line.split(':')[1]?.trim() || '';
        }
        if (line.match(/CLIENT\s*[:]/i) || line.includes('CLIENT NAME')) {
            metadata.clientName = line.split(':')[1]?.trim() || '';
        }
        if (line.match(/QUOTATION\s*[:#]/i)) {
            const match = line.match(/QUOTATION\s*[:#]\s*([A-Z0-9-]+)/i);
            if (match) metadata.quotationNumber = match[1];
        }
        if (line.match(/DATE\s*[:]/i) || line.includes('QUOTATION DATE')) {
            const d = line.match(/(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})/) || line.split(':')[1];
            if (d && typeof d === 'string') metadata.date = d.trim();
        }
        if (line.includes('TOTAL PROJECT') || line.includes('GRAND TOTAL')) {
            const match = line.match(/RM\s*([\d,]+\.?\d*)/);
            if (match) metadata.totalProject = match[1].replace(/,/g, '');
        }
    });

    let materials = [];

    if (detectedFormat === 'JOB_COST') {
        materials = parseJobCost(text);
    } else {
        let currentCat = 'MATERIALS';
        for (const line of lines) {
            const match = line.match(/^\d+\.?\s*(.+?)\s*[-–]\s*(\d+(\.\d+)?)\s*([a-z]+)?\s*[-–]\s*(?:RM)?\s*([\d,]+\.?\d{2})/i);
            if (match) {
                const p = cleanCurrency(match[5]);
                if (p <= 0) continue;
                const q = parseFloat(match[2]);
                materials.push({
                    id: generateId(),
                    category: currentCat,
                    item: match[1].trim(),
                    quantity: q,
                    unit: match[4] || 'pcs',
                    price: p,
                    pricePerUnit: p / q,
                    unitPrice: p / q
                });
            }
        }
    }

    if (!metadata.totalProject && materials.length > 0) {
        metadata.totalProject = materials.reduce((acc, m) => acc + (m.price || 0), 0).toFixed(2);
    }

    return {
        format: detectedFormat,
        metadata,
        materials
    };
};
