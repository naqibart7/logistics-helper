import React from 'react';
import { Trash2 } from 'lucide-react';

const SupplierCard = ({ supplier, onDelete }) => {
    return (
        <div className="bg-white rounded-xl shadow border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start">
                <div className="flex-1">
                    <h3 className="font-bold text-lg text-gray-900">{supplier.name}</h3>
                    <p className="text-sm text-gray-600 mt-1.5">
                        📍 {supplier.location || '—'} • 📞 {supplier.contact || '—'}
                    </p>
                    {supplier.whatsapp && (
                        <p className="text-sm text-gray-600 mt-1">💬 WA: {supplier.whatsapp}</p>
                    )}
                    <div className="flex flex-wrap gap-2 mt-4">
                        {supplier.categories.map((cat, idx) => (
                            <span
                                key={idx}
                                className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full"
                            >
                                {cat}
                            </span>
                        ))}
                    </div>
                </div>
                <button
                    onClick={onDelete}
                    className="text-red-600 hover:text-red-800 p-2 transition-colors"
                    aria-label="Delete supplier"
                >
                    <Trash2 size={20} />
                </button>
            </div>
        </div>
    );
};

export default SupplierCard;
